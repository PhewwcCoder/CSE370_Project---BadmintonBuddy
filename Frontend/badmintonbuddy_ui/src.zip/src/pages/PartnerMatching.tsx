import { useMemo, useState } from "react";
import { Card, CardBody, CardHeader, Button, Input, Toast, Divider } from "../components/ui";
import { api } from "../lib/api";

type PartnerRow = {
  user_id: number;
  name: string;
  skill_rating?: number;
};

function toISO(dateStr: string, timeStr: string) {
  // date: YYYY-MM-DD, time: HH:MM
  if (!dateStr || !timeStr) return "";
  return `${dateStr}T${timeStr}:00`;
}

export default function PartnerMatching() {
  const [date, setDate] = useState("");
  const [startClock, setStartClock] = useState("");
  const [endClock, setEndClock] = useState("");

  const [maxSkillDiff, setMaxSkillDiff] = useState(2);
  const [limit, setLimit] = useState(5);

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [partners, setPartners] = useState<PartnerRow[]>([]);
  const [info, setInfo] = useState<string | null>(null);

  const startISO = useMemo(() => toISO(date, startClock), [date, startClock]);
  const endISO = useMemo(() => toISO(date, endClock), [date, endClock]);

  const canSearch = useMemo(() => {
    return !!startISO && !!endISO && maxSkillDiff >= 0 && limit > 0;
  }, [startISO, endISO, maxSkillDiff, limit]);

  async function search() {
    setErr(null);
    setInfo(null);
    setBusy(true);
    setPartners([]);

    try {
      // call backend
      const res: any = await api.findPartners({
        start_time: startISO,
        end_time: endISO,
        max_skill_diff: maxSkillDiff,
        limit,
      });

      // tolerate shapes: array OR {partners:[...]}
      const list: any[] = Array.isArray(res) ? res : Array.isArray(res?.partners) ? res.partners : [];

      const normalized: PartnerRow[] = list.map((p: any) => ({
        user_id: Number(p.user_id ?? p.id),
        name: String(p.name ?? p.username ?? "Player"),
        skill_rating: p.skill_rating != null ? Number(p.skill_rating) : undefined,
      }));

      setPartners(normalized);

      if (normalized.length === 0) {
        setInfo("No available partners found for that time. Try a different slot.");
      }
    } catch (e: any) {
      setErr(e?.message || "Could not load partners");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {/* LEFT: SEARCH */}
      <Card>
        <CardHeader title="Find partners" subtitle="Choose a time slot and we’ll show who’s available." />
        <CardBody className="space-y-4">
          {err && <Toast tone="err">{err}</Toast>}
          {info && <Toast tone="ok">{info}</Toast>}

          <div className="grid gap-3">
            <div>
              <div className="text-xs text-slate-300 mb-1">Date</div>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-slate-300 mb-1">Start time</div>
                <Input type="time" value={startClock} onChange={(e) => setStartClock(e.target.value)} />
              </div>
              <div>
                <div className="text-xs text-slate-300 mb-1">End time</div>
                <Input type="time" value={endClock} onChange={(e) => setEndClock(e.target.value)} />
              </div>
            </div>

            <Divider />

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="text-xs text-slate-300 mb-1">Max skill difference</div>
                <Input
                  type="number"
                  min={0}
                  value={maxSkillDiff}
                  onChange={(e) => setMaxSkillDiff(Number(e.target.value))}
                />
              </div>

              <div>
                <div className="text-xs text-slate-300 mb-1">Results limit</div>
                <Input type="number" min={1} value={limit} onChange={(e) => setLimit(Number(e.target.value))} />
              </div>
            </div>

            <Button disabled={busy || !canSearch} onClick={search}>
              {busy ? "Searching…" : "Find partners"}
            </Button>

            <div className="text-xs text-white/50">
              Tip: If you don’t find anyone, widen the skill difference or try another hour.
            </div>
          </div>
        </CardBody>
      </Card>

      {/* RIGHT: RESULTS */}
      <Card className="md:col-span-2">
        <CardHeader title="Available partners" subtitle="Players who match your slot and skill range." />
        <CardBody className="space-y-3">
          {partners.length === 0 ? (
            <div className="text-sm text-white/60">No results to show yet.</div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {partners.map((p) => (
                <div
                  key={p.user_id}
                  className="rounded-xl border border-white/10 bg-white/5 p-4 flex items-start justify-between gap-3"
                >
                  <div>
                    <div className="text-white font-semibold">{p.name}</div>
                    <div className="text-xs text-white/60 mt-1">User ID: {p.user_id}</div>
                    <div className="text-xs text-white/60 mt-1">
                      Skill: {p.skill_rating != null ? p.skill_rating : "N/A"}
                    </div>
                  </div>

                  <Button
                    onClick={() => {
                      // Save prefill to sessionStorage for BookMatch page
                      sessionStorage.setItem(
                        "bb_booking_prefill",
                        JSON.stringify({
                          opponent_id: p.user_id,
                          opponent_name: p.name,
                          start_time: startISO,
                          end_time: endISO,
                        })
                      );
                      window.location.href = "/book";
                    }}
                  >
                    Book with {p.name.split(" ")[0]}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}

