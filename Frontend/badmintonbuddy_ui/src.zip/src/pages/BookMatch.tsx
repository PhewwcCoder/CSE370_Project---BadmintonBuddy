import bracuCourt from "../assets/bracu_court.jpg";
import { useEffect, useMemo, useState } from "react";
import { Card, CardBody, CardHeader, Button, Input, Toast, Divider } from "../components/ui";
import { api } from "../lib/api";

type Prefill = { opponent_id: number; opponent_name?: string; start_time: string; end_time: string };

export default function BookMatch() {
  const [courtId, setCourtId] = useState(1);
  const [opponentId, setOpponentId] = useState<number>(0);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [note, setNote] = useState<string | null>(null);

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  useEffect(() => {
    const raw = sessionStorage.getItem("bb_booking_prefill");
    if (!raw) return;
    try {
      const p = JSON.parse(raw) as Prefill;
      setOpponentId(p.opponent_id);
      setStartTime(p.start_time);
      setEndTime(p.end_time);
      setNote(p.opponent_name ? `Selected partner: ${p.opponent_name}` : "Partner details prefilled.");
    } catch {}
  }, []);

  const canSubmit = useMemo(() => courtId > 0 && opponentId > 0 && !!startTime && !!endTime, [courtId, opponentId, startTime, endTime]);

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card className="md:col-span-2">
        <CardHeader title="Book a court slot" subtitle="Choose a court, an opponent, and your preferred time." />
        <CardBody className="space-y-3">
          {note && <Toast tone="ok">{note}</Toast>}
          {err && <Toast tone="err">{err}</Toast>}
          {ok && <Toast tone="ok">{ok}</Toast>}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-xs text-slate-300 mb-1">Court ID</div>
              <Input type="number" min={1} value={courtId} onChange={(e) => setCourtId(Number(e.target.value))} />
            </div>
            <div>
              <div className="text-xs text-slate-300 mb-1">Opponent user ID</div>
              <Input type="number" min={1} value={opponentId || ""} onChange={(e) => setOpponentId(Number(e.target.value))} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-xs text-slate-300 mb-1">Start time (ISO)</div>
              <Input value={startTime} onChange={(e) => setStartTime(e.target.value)} placeholder="2025-12-28T17:00:00" />
            </div>
            <div>
              <div className="text-xs text-slate-300 mb-1">End time (ISO)</div>
              <Input value={endTime} onChange={(e) => setEndTime(e.target.value)} placeholder="2025-12-28T18:00:00" />
            </div>
          </div>

          <Button
            disabled={busy || !canSubmit}
            onClick={async () => {
              setErr(null);
              setOk(null);
              setBusy(true);
              try {
                const res = await api.bookMatch({ court_id: courtId, opponent_id: opponentId, start_time: startTime, end_time: endTime });
                setOk(`Booking confirmed! Match ID: ${res.match_id}`);
              } catch (e: any) {
                setErr(e.message || "Booking failed");
              } finally {
                setBusy(false);
              }
            }}
          >
            {busy ? "Booking…" : "Confirm booking"}
          </Button>

          <Divider />

          <div className="text-xs text-white/50">
            Note: Use ISO time format (example: <span className="text-white/70">2025-12-28T17:00:00</span>).
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Court tips" subtitle="Before you confirm" />
        <CardBody className="text-sm text-slate-300 space-y-2">
          <div>• Use a valid Court ID (for example: 1, 2, 3).</div>
          <div>• Make sure the opponent’s user ID is correct.</div>
          <div>• Start time must be earlier than end time.</div>
          <div>• If the slot is already taken, choose another time.</div>

          <div className="mt-4 overflow-hidden rounded-xl border border-white/10">
            <img src={bracuCourt} alt="BRACU Badminton Court" className="h-48 w-full object-cover" loading="lazy" />
            <div className="px-3 py-2 text-xs text-white/60 text-center">BRACU Indoor Badminton Court</div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

