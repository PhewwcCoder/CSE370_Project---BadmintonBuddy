import { useEffect, useMemo, useState } from "react";
import { Card, CardBody, CardHeader, Button, Input, Toast, Divider } from "../components/ui";
import { api } from "../lib/api";

type MatchRow = {
  match_id?: number;
  start_time: string;
  end_time: string;
  court_id?: number;
  player1_name?: string;
  player2_name?: string;
  match_type?: string;
};

type CalStatus =
  | { connected: false }
  | { connected: true; google_account_email?: string; token_expiry?: string | null };

function ymd(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function parseDateSafe(s: string) {
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function pretty(dt: string) {
  const d = parseDateSafe(dt);
  return d ? d.toLocaleString() : dt;
}

function sameYMD(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function monthLabel(d: Date) {
  return d.toLocaleString(undefined, { month: "long", year: "numeric" });
}

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function endOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0);
}

function addMonths(d: Date, delta: number) {
  return new Date(d.getFullYear(), d.getMonth() + delta, 1);
}

function buildCalendarGrid(month: Date) {
  const first = startOfMonth(month);
  const last = endOfMonth(month);

  // make week start on Sunday (0)
  const start = new Date(first);
  start.setDate(first.getDate() - first.getDay());

  const end = new Date(last);
  end.setDate(last.getDate() + (6 - last.getDay()));

  const days: Date[] = [];
  const cur = new Date(start);

  while (cur <= end) {
    days.push(new Date(cur));
    cur.setDate(cur.getDate() + 1);
  }
  return days;
}

export default function Calendar() {
  const [status, setStatus] = useState<CalStatus>({ connected: false });
  const [matches, setMatches] = useState<MatchRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  const [month, setMonth] = useState(() => new Date());
  const [selected, setSelected] = useState<Date>(() => new Date());

  // Connect form (simple + clean)
  const [showConnect, setShowConnect] = useState(false);
  const [googleEmail, setGoogleEmail] = useState("");
  const [tokenExpiry, setTokenExpiry] = useState(""); // ISO string
  const [accessToken, setAccessToken] = useState("");
  const [refreshToken, setRefreshToken] = useState("");

  async function loadAll() {
    setErr(null);
    setOk(null);
    setBusy(true);
    try {
      // 1) calendar status
      const s: any = await api.calendarStatus();
      setStatus(
        s?.connected
          ? { connected: true, google_account_email: s.google_account_email, token_expiry: s.token_expiry }
          : { connected: false }
      );

      // 2) match history (used only to show dots + day list)
      const h: any = await api.matchHistory();
      const list: MatchRow[] = Array.isArray(h) ? h : Array.isArray(h?.matches) ? h.matches : [];
      setMatches(list);
    } catch (e: any) {
      setErr(e?.message || "Could not load calendar data");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const days = useMemo(() => buildCalendarGrid(month), [month]);

  // Group matches by date for “dots”
  const matchDays = useMemo(() => {
    const set = new Set<string>();
    for (const m of matches) {
      const d = parseDateSafe(m.start_time);
      if (!d) continue;
      set.add(ymd(d));
    }
    return set;
  }, [matches]);

  // Matches on selected day
  const selectedMatches = useMemo(() => {
    const out: MatchRow[] = [];
    for (const m of matches) {
      const d = parseDateSafe(m.start_time);
      if (!d) continue;
      if (sameYMD(d, selected)) out.push(m);
    }
    // sort by time
    out.sort((a, b) => (parseDateSafe(a.start_time)?.getTime() || 0) - (parseDateSafe(b.start_time)?.getTime() || 0));
    return out;
  }, [matches, selected]);

  async function saveCredentials() {
    setErr(null);
    setOk(null);
    setBusy(true);
    try {
      await api.calendarConnect({
        google_account_email: googleEmail.trim(),
        access_token: accessToken.trim(),
        refresh_token: refreshToken.trim(),
        token_expiry: tokenExpiry.trim(),
      });
      setOk("Calendar connected successfully.");
      setShowConnect(false);
      await loadAll();
    } catch (e: any) {
      setErr(e?.message || "Could not save credentials");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {/* LEFT: CALENDAR */}
      <Card className="md:col-span-2">
        <CardHeader title="Calendar" subtitle="See your match days and manage calendar connection." />
        <CardBody className="space-y-4">
          {err && <Toast tone="err">{err}</Toast>}
          {ok && <Toast tone="ok">{ok}</Toast>}

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Button onClick={() => setMonth(addMonths(month, -1))}>◀</Button>
              <div className="text-white font-semibold">{monthLabel(month)}</div>
              <Button onClick={() => setMonth(addMonths(month, 1))}>▶</Button>
            </div>

            <div className="flex items-center gap-2">
              <Button disabled={busy} onClick={loadAll}>
                {busy ? "Refreshing…" : "Refresh"}
              </Button>

              <Button
                onClick={() => setShowConnect(true)}
                className={status.connected ? "opacity-90" : ""}
              >
                {status.connected ? "Manage connection" : "Connect calendar"}
              </Button>
            </div>
          </div>

          <Divider />

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-2 text-sm">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((w) => (
              <div key={w} className="text-white/60 text-xs px-2">
                {w}
              </div>
            ))}

            {days.map((d) => {
              const inMonth = d.getMonth() === month.getMonth();
              const isSelected = sameYMD(d, selected);
              const hasMatch = matchDays.has(ymd(d));
              return (
                <button
                  key={d.toISOString()}
                  onClick={() => setSelected(d)}
                  className={[
                    "relative rounded-xl border px-2 py-3 text-left transition",
                    "border-white/10 bg-white/5 hover:bg-white/10",
                    inMonth ? "text-white" : "text-white/40",
                    isSelected ? "ring-2 ring-white/30 bg-white/10" : "",
                  ].join(" ")}
                >
                  <div className="text-sm font-medium">{d.getDate()}</div>
                  {hasMatch ? (
                    <div className="absolute bottom-2 left-2 h-2 w-2 rounded-full bg-white/70" />
                  ) : null}
                </button>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {/* RIGHT: DETAILS */}
      <Card>
        <CardHeader
          title="Details"
          subtitle={status.connected ? "Connected" : "Not connected"}
        />
        <CardBody className="space-y-3 text-sm text-slate-300">
          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="text-xs text-white/60">Selected day</div>
            <div className="text-white font-medium">{selected.toDateString()}</div>
          </div>

          <div className="rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="text-xs text-white/60">Calendar connection</div>
            {status.connected ? (
              <>
                <div className="text-white font-medium">Connected</div>
                {status.google_account_email ? (
                  <div className="text-white/70 text-xs mt-1">{status.google_account_email}</div>
                ) : null}
                {status.token_expiry ? (
                  <div className="text-white/50 text-xs mt-1">Expires: {status.token_expiry}</div>
                ) : null}
              </>
            ) : (
              <div className="text-white font-medium">Not connected</div>
            )}
          </div>

          <Divider />

          <div className="text-white font-semibold">Matches on this day</div>

          {selectedMatches.length === 0 ? (
            <div className="text-white/60">No matches on this date.</div>
          ) : (
            <div className="space-y-2">
              {selectedMatches.map((m, idx) => (
                <div key={(m.match_id ?? idx) as any} className="rounded-xl border border-white/10 bg-white/5 p-3">
                  <div className="text-white font-medium">
                    {(m.player1_name && m.player2_name) ? `${m.player1_name} vs ${m.player2_name}` : "Match"}
                  </div>
                  <div className="text-xs text-white/60 mt-1">
                    {pretty(m.start_time)} → {pretty(m.end_time)}
                    {m.court_id != null ? ` • Court ${m.court_id}` : ""}
                    {m.match_type ? ` • ${m.match_type}` : ""}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      {/* CONNECT POPUP */}
      {showConnect ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowConnect(false)} />
          <div className="relative w-full max-w-xl">
            <Card>
              <CardHeader
                title={status.connected ? "Update calendar connection" : "Connect your calendar"}
                subtitle="Save account details so the system can check availability."
              />
              <CardBody className="space-y-3">
                {err && <Toast tone="err">{err}</Toast>}

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-xs text-slate-300 mb-1">Google email</div>
                    <Input value={googleEmail} onChange={(e) => setGoogleEmail(e.target.value)} placeholder="your@email.com" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-300 mb-1">Token expiry (ISO)</div>
                    <Input
                      value={tokenExpiry}
                      onChange={(e) => setTokenExpiry(e.target.value)}
                      placeholder="2025-12-30T10:00:00"
                    />
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-xs text-slate-300 mb-1">Access token</div>
                    <Input value={accessToken} onChange={(e) => setAccessToken(e.target.value)} placeholder="Paste token" />
                  </div>
                  <div>
                    <div className="text-xs text-slate-300 mb-1">Refresh token</div>
                    <Input value={refreshToken} onChange={(e) => setRefreshToken(e.target.value)} placeholder="Paste token" />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <Button onClick={() => setShowConnect(false)}>Cancel</Button>
                  <Button disabled={busy || !googleEmail || !tokenExpiry} onClick={saveCredentials}>
                    {busy ? "Saving…" : "Save"}
                  </Button>
                </div>

                <div className="text-xs text-white/50">
                  After connecting, you can later extend the backend to block booking times that clash with calendar events.
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      ) : null}
    </div>
  );
}
