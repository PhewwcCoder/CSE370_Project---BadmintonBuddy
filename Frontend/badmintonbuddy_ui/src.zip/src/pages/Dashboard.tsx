import { useEffect, useMemo, useState } from "react";
import { Card, CardBody, CardHeader, Button, Toast, Divider } from "../components/ui";
import { api } from "../lib/api";
import { useAuth } from "../state/auth";

type MatchRow = {
  match_id?: number;
  id?: number;

  start_time: string;
  end_time: string;
  court_id: number;
  match_type: string;

  opponent_name?: string;

  // winner variants (backend may differ)
  winner?: number | string;
  winner_id?: number | string;
  winnerId?: number | string;
  winner_name?: string;
};

function fmt(dt: string) {
  const d = new Date(dt);
  return isNaN(d.getTime()) ? dt : d.toLocaleString();
}

// Try many common shapes safely
function extractMatches(res: any): MatchRow[] {
  if (!res) return [];

  // most common: array
  if (Array.isArray(res)) return res as MatchRow[];

  // common wrappers
  const candidates = [res.matches, res.history, res.results, res.data];

  for (const c of candidates) {
    if (Array.isArray(c)) return c as MatchRow[];
  }

  // sometimes: { data: { matches: [...] } }
  if (res.data && typeof res.data === "object") {
    const deep = [res.data.matches, res.data.history, res.data.results];
    for (const d of deep) {
      if (Array.isArray(d)) return d as MatchRow[];
    }
  }

  return [];
}

export default function Dashboard() {
  const { user } = useAuth();

  const [preview, setPreview] = useState<MatchRow[]>([]);
  const [allCount, setAllCount] = useState(0);
  const [wins, setWins] = useState(0);

  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function load() {
    setErr(null);
    setBusy(true);

    try {
      const res: any = await api.matchHistory();
      const list = extractMatches(res);

      // DEV debug (you can keep or delete later)
      console.log("DASHBOARD matchHistory raw:", res);
      console.log("DASHBOARD extracted matches length:", list.length);

      setAllCount(list.length);
      setPreview(list.slice(0, 5));

      // compute wins (best-effort)
      const myName = (user?.name || "").toLowerCase();
      const myId = (user as any)?.user_id ?? (user as any)?.id;

      let winCount = 0;

      for (const m of list) {
        const w =
          (m as any)?.winner ??
          (m as any)?.winner_id ??
          (m as any)?.winnerId ??
          (m as any)?.winner_name;

        if (w == null) continue;

        // numeric id compare
        if (myId != null && String(w) === String(myId)) {
          winCount++;
          continue;
        }

        // name compare
        if (typeof w === "string" && w.toLowerCase() === myName) {
          winCount++;
          continue;
        }
      }

      setWins(winCount);
    } catch (e: any) {
      setErr(e?.message || "Failed to load dashboard");
      setAllCount(0);
      setPreview([]);
      setWins(0);
    } finally {
      setBusy(false);
    }
  }

  // ✅ KEY FIX:
  // Run once when the user becomes available (so session cookie/auth is ready),
  // and also re-run if user changes.
  useEffect(() => {
    if (!user) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const winRate = useMemo(() => {
    if (allCount <= 0) return 0;
    return Math.round((wins / allCount) * 100);
  }, [wins, allCount]);

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {/* MAIN */}
      <Card className="md:col-span-2">
        <CardHeader
          title={`Hi, ${user?.name ?? "Player"} 👋`}
          subtitle="Your activity overview and recent matches."
        />
        <CardBody className="space-y-4">
          {err && <Toast tone="err">{err}</Toast>}

          <div className="text-slate-300 text-sm">
            Welcome back! Use the navigation above to find partners, book courts, and track your matches.
          </div>

          <Divider />

          <div className="grid gap-3 sm:grid-cols-3">
            <Stat title="Wins" value={wins} />
            <Stat title="Total matches" value={allCount} />
            <Stat title="Win rate" value={`${winRate}%`} />
          </div>

          <Divider />

          <div className="flex items-center justify-between">
            <div className="text-white font-semibold">Recent matches</div>
            <Button disabled={busy} onClick={load}>
              {busy ? "Refreshing…" : "Refresh"}
            </Button>
          </div>

          {preview.length === 0 ? (
            <div className="text-sm text-white/60">No matches yet.</div>
          ) : (
            <div className="space-y-2">
              {preview.map((m, i) => (
                <div
                  key={m.match_id ?? m.id ?? i}
                  className="rounded-xl border border-white/10 bg-white/5 p-4"
                >
                  <div className="text-white font-medium">
                    {m.opponent_name ? `You vs ${m.opponent_name}` : "Match"}
                  </div>
                  <div className="text-xs text-white/60 mt-1">
                    {fmt(m.start_time)} → {fmt(m.end_time)} • Court {m.court_id} • {m.match_type}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      {/* SIDE */}
      <Card>
        <CardHeader title="Quick status" subtitle="Account information" />
        <CardBody className="space-y-3 text-sm text-slate-300">
          <div>
            <div className="text-xs text-white/60">Role</div>
            <div className="text-white font-medium">{user?.role}</div>
          </div>

          <div>
            <div className="text-xs text-white/60">Calendar</div>
            <div className="text-white font-medium">Not connected</div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}

function Stat({ title, value }: { title: string; value: any }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/5 p-4">
      <div className="text-xs text-white/60">{title}</div>
      <div className="mt-1 text-2xl font-semibold text-white">{value}</div>
    </div>
  );
}








