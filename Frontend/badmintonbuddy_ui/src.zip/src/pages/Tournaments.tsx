import { useEffect, useMemo, useState } from "react";
import { Card, CardBody, CardHeader, Button, Input, Textarea, Toast, Divider, Badge } from "../components/ui";
import { api } from "../lib/api";
import { useAuth } from "../state/auth";

type Tournament = { tournament_id: number; name: string; description: string | null; created_by: number; max_players: number; status: string };

export default function Tournaments() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [items, setItems] = useState<Tournament[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [maxPlayers, setMaxPlayers] = useState(16);

  const [selected, setSelected] = useState<Tournament | null>(null);
  const [matches, setMatches] = useState<any[] | null>(null);

  async function refresh() {
    const res = await api.tournaments();
    setItems(res.tournaments);
  }

  useEffect(() => {
    refresh().catch(() => {});
  }, []);

  const selectedId = selected?.tournament_id;
  const canCreate = useMemo(() => isAdmin && name.trim().length > 0 && maxPlayers >= 2, [isAdmin, name, maxPlayers]);

  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card className="md:col-span-2">
        <CardHeader title="Tournaments" subtitle="GET /api/tournaments/ • Join • Start (admin) • Matches" />
        <CardBody className="space-y-3">
          {err && <Toast tone="err">{err}</Toast>}
          {ok && <Toast tone="ok">{ok}</Toast>}

          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => refresh().catch(() => {})}>
              Refresh
            </Button>
            {selectedId && (
              <Button
                variant="ghost"
                onClick={async () => {
                  setErr(null);
                  try {
                    const res = await api.tournamentMatches(selectedId);
                    setMatches(res.matches || res || []);
                  } catch (e: any) {
                    setErr(e.message || "Failed to load matches");
                  }
                }}
              >
                Load matches
              </Button>
            )}
          </div>

          <div className="space-y-3">
            {items.map((t) => (
              <div
                key={t.tournament_id}
                className={
                  "rounded-2xl border p-4 transition cursor-pointer " +
                  (selectedId === t.tournament_id ? "border-white/30 bg-slate-900/70" : "border-slate-800 bg-slate-950/30 hover:bg-slate-950/50")
                }
                onClick={() => {
                  setSelected(t);
                  setMatches(null);
                }}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div>
                    <div className="font-medium text-white">{t.name}</div>
                    {t.description ? <div className="text-sm text-slate-300 mt-1">{t.description}</div> : <div className="text-sm text-slate-500 mt-1">No description</div>}
                    <div className="mt-2 flex gap-2 flex-wrap">
                      <Badge>id: {t.tournament_id}</Badge>
                      <Badge>max: {t.max_players}</Badge>
                      <Badge>status: {t.status}</Badge>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    <Button
                      variant="ghost"
                      onClick={async (e) => {
                        e.stopPropagation();
                        setErr(null);
                        setOk(null);
                        try {
                          await api.joinTournament(t.tournament_id);
                          setOk(`Joined: ${t.name}`);
                        } catch (e: any) {
                          setErr(e.message || "Join failed");
                        }
                      }}
                    >
                      Join
                    </Button>

                    {isAdmin && t.status === "upcoming" && (
                      <Button
                        onClick={async (e) => {
                          e.stopPropagation();
                          setErr(null);
                          setOk(null);
                          setBusy(true);
                          try {
                            const res = await api.startTournament(t.tournament_id, {
                              court_id: 1,
                              start_time: new Date().toISOString().slice(0, 19),
                              match_minutes: 60,
                            });
                            setOk(`Started: round 1 generated (${(res.matches_created || []).length} matches)`);
                            await refresh();
                          } catch (e: any) {
                            setErr(e.message || "Start failed");
                          } finally {
                            setBusy(false);
                          }
                        }}
                        disabled={busy}
                      >
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                {selectedId === t.tournament_id && matches && (
                  <div className="mt-4">
                    <Divider />
                    <div className="text-sm font-semibold mb-2">Matches</div>
                    <div className="space-y-2">
                      {matches.length === 0 ? (
                        <div className="text-sm text-slate-400">No matches returned.</div>
                      ) : (
                        matches.map((m: any) => (
                          <div key={m.match_id} className="rounded-xl border border-slate-800 bg-slate-950/20 p-3">
                            <div className="flex flex-wrap items-center gap-2 justify-between">
                              <div className="text-sm">
                                <span className="text-slate-400">match_id</span> <span className="text-white font-medium">{m.match_id}</span>{" "}
                                <span className="text-slate-500">•</span>{" "}
                                <span className="text-slate-400">round</span> <span className="text-white">{m.round}</span>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  onClick={async () => {
                                    const winner = Number(prompt("Winner user_id?"));
                                    if (!winner) return;
                                    const score = prompt("Score (optional), e.g., 21-18, 21-17") || undefined;
                                    try {
                                      await api.reportMatchResult(m.match_id, { winner_id: winner, score });
                                      setOk(`Result saved for match ${m.match_id}`);
                                    } catch (e: any) {
                                      setErr(e.message || "Failed to report result");
                                    }
                                  }}
                                >
                                  Report result
                                </Button>
                              </div>
                            </div>
                            <div className="text-xs text-slate-400 mt-2">
                              P1: {m.player1_id} • P2: {m.player2_id} • {m.start_time} → {m.end_time}
                            </div>
                            {m.winner_id ? <div className="text-xs text-emerald-200 mt-2">Winner: {m.winner_id} {m.score ? `• Score: ${m.score}` : ""}</div> : <div className="text-xs text-slate-500 mt-2">Not reported yet</div>}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Admin tools" subtitle={isAdmin ? "POST /api/tournaments/create/" : "Login as admin to create tournaments"} />
        <CardBody className="space-y-3">
          {!isAdmin ? (
            <div className="text-sm text-slate-400">You are logged in as <span className="text-white">{user?.role}</span>. Creation is disabled.</div>
          ) : (
            <>
              <div>
                <div className="text-xs text-slate-300 mb-1">Name</div>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="BRAC Badminton Open" />
              </div>
              <div>
                <div className="text-xs text-slate-300 mb-1">Description</div>
                <Textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Optional" />
              </div>
              <div>
                <div className="text-xs text-slate-300 mb-1">Max players</div>
                <Input type="number" min={2} value={maxPlayers} onChange={(e) => setMaxPlayers(Number(e.target.value))} />
              </div>
              <Button
                className="w-full"
                disabled={!canCreate}
                onClick={async () => {
                  setErr(null);
                  setOk(null);
                  try {
                    const res = await api.createTournament({ name, description: desc || undefined, max_players: maxPlayers });
                    setOk(`Created tournament_id=${res.tournament_id}`);
                    setName("");
                    setDesc("");
                    await refresh();
                  } catch (e: any) {
                    setErr(e.message || "Create failed");
                  }
                }}
              >
                Create
              </Button>
              <Divider />
              <div className="text-xs text-slate-500">
                Note: Your backend checks admin via session role (<code className="text-slate-300">request.session[&quot;role&quot;]</code>).
              </div>
            </>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
