export type ApiError = { error: string } & Record<string, unknown>;

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: "include", // IMPORTANT: Django session cookie
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    ...init,
  });

  const text = await res.text();
  const data = text ? (JSON.parse(text) as any) : {};

  if (!res.ok) {
    const msg = (data && data.error) || `Request failed: ${res.status}`;
    throw new Error(msg);
  }
  return data as T;
}

export const api = {
  signup: (body: { name: string; email: string; password: string }) =>
    request<{ message: string; user: any }>("/api/users/signup/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  login: (body: { email: string; password: string }) =>
    request<{ message: string; user: any }>("/api/users/login/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  logout: () =>
    request<{ message: string }>("/api/users/logout/", { method: "POST", body: "{}" }),

  calendarStatus: () =>
    request<{ connected: boolean; google_account_email?: string; token_expiry?: string | null }>(
      "/api/users/calendar/status/"
    ),

  calendarConnect: (body: {
    google_account_email: string;
    access_token: string;
    refresh_token: string;
    token_expiry: string; // ISO
  }) =>
    request<{ message: string; user_id: number }>("/api/users/calendar/connect/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  userStats: () =>
    request<{
      user: {
        user_id: number;
        name: string;
        wins: number;
        total_matches: number;
        win_rate_percent: number;
        skill_rating: number;
        friendly_matches: number;
        tournament_matches: number;
      };
    }>("/api/users/stats/"),

  matchHistory: () =>
    request<{
      user_id: number;
      history: Array<{
        match_id: number;
        court_id: number;
        player1_id: number;
        player1_name: string;
        player2_id: number;
        player2_name: string;
        start_time: string;
        end_time: string;
        tournament_id: number | null;
        round: number | null;
        winner_id: number | null;
        score: string | null;
      }>;
    }>("/api/matches/history/"),

  findPartners: (params: { start_time: string; end_time: string; max_skill_diff?: number; limit?: number }) => {
    const q = new URLSearchParams();
    q.set("start_time", params.start_time);
    q.set("end_time", params.end_time);
    if (params.max_skill_diff != null) q.set("max_skill_diff", String(params.max_skill_diff));
    if (params.limit != null) q.set("limit", String(params.limit));
    return request<{
      me: { user_id: number; skill_rating: number };
      desired: { start_time: string; end_time: string };
      available_partners: Array<{ user_id: number; name: string; email: string; skill_rating: number }>;
    }>(`/api/matches/partners/?${q.toString()}`);
  },

  bookMatch: (body: { court_id: number; opponent_id: number; start_time: string; end_time: string }) =>
    request<{ message: string; match_id: number }>("/api/matches/book/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  tournaments: () =>
    request<{ tournaments: Array<{ tournament_id: number; name: string; description: string | null; created_by: number; max_players: number; status: string }> }>(
      "/api/tournaments/"
    ),

  createTournament: (body: { name: string; description?: string; max_players: number }) =>
    request<{ message: string; tournament_id: number }>("/api/tournaments/create/", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  joinTournament: (tournament_id: number) =>
    request<{ message: string }>(`/api/tournaments/${tournament_id}/join/`, {
      method: "POST",
      body: "{}",
    }),

  startTournament: (tournament_id: number, body?: { court_id?: number; start_time?: string; match_minutes?: number }) =>
    request<any>(`/api/tournaments/${tournament_id}/start/`, {
      method: "POST",
      body: JSON.stringify(body || {}),
    }),

  tournamentMatches: (tournament_id: number) =>
    request<any>(`/api/tournaments/${tournament_id}/matches/`),

  reportMatchResult: (match_id: number, body: { winner_id: number; score?: string }) =>
    request<any>(`/api/tournaments/match/${match_id}/result/`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  leaderboard: () =>
    request<{ leaderboard: Array<{ user_id: number; name: string; wins: number; total_matches: number; skill_rating: number }> }>(
      "/api/tournaments/leaderboard/"
    ),

  tournamentLeaderboard: (tournament_id: number) =>
    request<{ tournament_id: number; leaderboard: Array<{ user_id: number; name: string; matches_played: number; wins: number }> }>(
      `/api/tournaments/${tournament_id}/leaderboard/`
    ),

  completeTournament: (tournament_id: number) =>
    request<any>(`/api/tournaments/${tournament_id}/complete/`, {
      method: "POST",
      body: "{}",
    }),
};
